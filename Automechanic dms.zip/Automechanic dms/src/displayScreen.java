import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Vector;

import static java.lang.String.*;

public class displayScreen extends JFrame {

    private JScrollPane pane;
    private JPanel displayScreen;
    private JTable dispVal;
    private JButton closeScreenButton;

    /**
     * The first method within this class opens the screen and references the appropriate screen form to open, as well
     * as formatting the parameters and features of the GUI.
     * <p>This class opens a screen which displays values using a table model and reformats all values within the
     * internal global hashmap. It does not communicate with the database</p>
     * The return command is for debugging purposes
     * @return command(essentially zero to reset the loop)
     */
    public static String retCommandDis() {
        return "0";
    }

    displayScreen() {
        setContentPane(displayScreen);
        this.setTitle("Display Appointment");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        closeScreenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });

    }

    private void createUIComponents() {

        DefaultTableModel tableModel = new DefaultTableModel
                (new Object[]{"ID","Car","Owner","Date","Repair","Return","Note"},0);
        Iterator<String> iter = Driver.appointments.keySet().iterator();
        while (iter.hasNext()){
            Vector<String> row = new Vector<>(7);
            String key = iter.next();
            row.addElement(key);
            String[] values = new String[]{Driver.appointments.get(key).car,
                    Driver.appointments.get(key).owner,
                    Driver.appointments.get(key).date,
                    Driver.appointments.get(key).repair,
                    String.valueOf(Driver.appointments.get(key).rturn),
                    Driver.appointments.get(key).note};


            for( String item : values) {
                row.addElement(valueOf(item));
            }

            tableModel.addRow(row);
        }

        dispVal = new JTable(tableModel);
        pane = new JScrollPane(dispVal);
        add(pane);
        add(dispVal);

    }
}