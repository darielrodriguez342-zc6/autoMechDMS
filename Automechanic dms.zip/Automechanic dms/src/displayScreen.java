import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Vector;

import static java.lang.String.*;

public class displayScreen extends JFrame {

    private JScrollPane pane;
    private JPanel displayScreen;
    private JTable dispVal;
    private JButton closeScreenButton;

    public static String retCommandDis() {
        return "0";
    }

    displayScreen() {
        setContentPane(displayScreen);
        this.setTitle("Display Appointment");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        closeScreenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });



        DefaultTableModel tableModel = new DefaultTableModel
                (new Object[]{"ID","Car","Owner","Date","Repair","Return","Note"},0);
        Iterator<String> iter = Driver.appointments.keySet().iterator();
        while (iter.hasNext()){
            Vector<String> row = new Vector<>(7);
            String key = iter.next();
            row.addElement(key);
            Apt[] values = new Apt[]{Driver.appointments.get(key)};
            for( Apt item : values) {
                row.addElement(valueOf(item));
            }

            tableModel.addRow(row);
        }


    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        DefaultTableModel tableModel = new DefaultTableModel
                (new Object[]{"ID","Car","Owner","Date","Repair","Return","Note"},0);
        Iterator<String> iter = Driver.appointments.keySet().iterator();
        while (iter.hasNext()){
            Vector<String> row = new Vector<>(7);
            String key = iter.next();
            row.addElement(key);
            Apt[] values = new Apt[]{Driver.appointments.get(key)};
            for( Apt item : values) {
                row.addElement(valueOf(item));
            }

            tableModel.addRow(row);
        }

        dispVal = new JTable(tableModel);
        pane = new JScrollPane(dispVal);
        add(pane);
        add(dispVal);

    }
}