import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class homeScreen extends JFrame {

    private JButton createAppointmentButton;
    private JButton displayAppointmentsButton;
    private JButton updateValueInAppointmentsButton;
    private JButton importDataFromFileButton;
    private JButton setReturnJobToButton;
    private JButton exitApplicationButton;
    private JPanel homeScreen;
    private JButton removeAppointmentButton;

    static String command = "0";

    public static String retCommand(){
        //System.out.println("command is "+ command);
        return command;
    }




    //Frame for homescreen
    homeScreen(){
        setContentPane(homeScreen);
        this.setTitle("AutoMechanicDMS");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        ImageIcon image = new ImageIcon("images.png");
        this.setIconImage(image.getImage());
        this.getContentPane().setBackground(Color.white);


        //select add command
        createAppointmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                command = "1";
                retCommand();
                setVisible(false);
                new AddScreen();


            }
        });

        //select remove command
        removeAppointmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "2";
                retCommand();
                setVisible(false);
                new RemoveScreen();
            }
        });

        //select display command
        displayAppointmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "3";
                setVisible(false);
                new displayScreen();

            }
        });

        //select update command
        updateValueInAppointmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "4";
                retCommand();
                new updateScreen();
                setVisible(false);
            }
        });

        //select return command
        setReturnJobToButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "5";
                retCommand();
                new quickChange();
                setVisible(false);
            }
        });

        //select import command
        importDataFromFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "6";
                retCommand();
                new importScreen();
                setVisible(false);
            }
        });

        //select exit command
        exitApplicationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                command = "7";
                retCommand();
                dispose();
            }
        });

    }

}