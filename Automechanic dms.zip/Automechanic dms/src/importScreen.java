import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;


public class importScreen extends JFrame {

    private JButton button1;
    private JPanel importScreen;
    private JButton doneButton;

    importScreen() {
        setContentPane(importScreen);
        this.setTitle("Import File");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Apt> appts = new ArrayList<>();
                //for me : C:\Users\Dariel\Desktop\dmsin.txt
                String file = "C:\\Users\\Dariel\\Desktop\\dmsin.txt";
                /*
                String ID;
                String car;
                String owner;
                String date;
                String repair;
                boolean return;
                String note;
                ResultSet ResSt = null;
                 */

                try {
                    appts = Driver.loadFile(file);
                    for (Apt apt : appts ) {
                        Driver.appointments.put(apt.getID(),apt);
                    }
                    /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    for (loop till 999999 using var i for increment){
                        ID = i;
                        Statement stmt = con.CreateStatement();
                        String sqlGTOBJ = "SELECT ID,car,owner,date,repair,return,note FROM amdmsTblOne WHERE id = " + i;
                        ResSt = stmt.executeQuery(sqlGTOBJ);
                        ID = (convert to String and add zeros before first number if needed)ResSt.getInt("ID");
                        car = ResSt.getString("car");
                        if(car == null){
                            continue;
                        }
                        owner = ResSt.getString("owner");
                        date = ResSt.getString("date");
                        repair = ResSt.getString("repair");
                        return = ResSt.getString("return");
                        (change return to boolean and make sure it is only "true" or "false")
                        note = ResSt.getString("note");
                        Driver.appointments.put(ID ,new Apt(ID,car,owner,date,repair,return,note);
                    }
                    (close connection to database)

                     */

                } catch (Exception f) {
                    throw new RuntimeException(f);
                }

            }
        });
        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });

    }
}