import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class importScreen extends JFrame {

    private JTextField textField1;
    private JButton button1;
    private JPanel importScreen;
    private JButton doneButton;

    importScreen() {
        setContentPane(importScreen);
        this.setTitle("Import File");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Apt> appts = new ArrayList<>();
                //for me : C:\Users\Dariel\Desktop\dmsin.txt
                String fileName = textField1.getText();
                try {
                    appts = Driver.loadFile(fileName);
                    for (Apt apt : appts ) {
                        Driver.appointments.put(apt.getID(),apt);
                    }

                } catch (Exception f) {
                    throw new RuntimeException(f);
                }

            }
        });
        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });

    }
}