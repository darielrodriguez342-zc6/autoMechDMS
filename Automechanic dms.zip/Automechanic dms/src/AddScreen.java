import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddScreen extends JFrame {
    JFrame frameAdd = new JFrame();
    private JPanel AddScreen;
    private JTextField textField7;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JButton addAppointmentToListButton;
    private JTextField textField1;
    private JButton closeScreenButton;

    boolean check1;
    boolean check2;
    boolean check3;
    boolean check4;
    boolean check5;
    boolean check6;


    AddScreen(){
        setContentPane(AddScreen);
        this.setTitle("Add Appointment");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);


        //add appt command
        addAppointmentToListButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                if(!(Driver.appointments.containsKey(textField1.getText()))&& textField1.getText().matches("[0-9]{6}")) {
                    if(!(textField7.getText().isEmpty())){check1=true;}
                    else {JOptionPane.showMessageDialog(null, "Owner slot is empty");}

                    if(!(textField2.getText().isEmpty())){check2=true;}
                    else{JOptionPane.showMessageDialog(null, "Car slot is empty");}

                    if(!(textField3.getText().isEmpty())){check3=true;}
                    else{JOptionPane.showMessageDialog(null, "Repair slot is empty");}

                    if(!(textField4.getText().isEmpty())){check4=true;}
                    else{JOptionPane.showMessageDialog(null, "Date slot is empty");}

                    if(!(textField5.getText().isEmpty())&&(textField5.getText().equals("true")||textField5.getText().equals("false"))){check5=true;}
                    else{JOptionPane.showMessageDialog(null, "Return slot is empty, or not in correct syntax");}

                    if(!(textField6.getText().isEmpty())){check6=true;}
                    else{JOptionPane.showMessageDialog(null, "Note slot is empty");}

                    if(check1==true&&check2==true&&check3==true&&check4==true&&check5==true&&check6==true){
                    Driver.appointments.put( textField1.getText() ,new Apt(textField1.getText(), textField2.getText(), textField7.getText(), textField4.getText(), textField3.getText(), Boolean.valueOf(textField5.getText()), textField6.getText()));
                    }
                }
                else{JOptionPane.showMessageDialog(null, "id is not a 6 digit number or id found in database, please enter new id");}

                }
        });

        closeScreenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            setVisible(false);
            new homeScreen();
            }
        });

    }


}
