import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Driver{

    public static HashMap<String, Apt> appointments;
    static Scanner scnr;
    private JPanel panel1;

    public static void main(String[] args) throws InterruptedException {

        //Declare and Initialize variables
        String aptID = "";
        String idToDel;
        String idToUpDt;
        String upDtCh;
        String upDtChOld;
        String upDtChNew;
        String car = "";
        String carNew;
        String owner = "";
        String date = "";
        String repair = "";
        String note = "";
        String rTurnStr = "";
        String command;
        boolean rturn;
        boolean upDtChBool;
        boolean done = false;
        int rturnInt;



        //Ar list to grab data fed in
        ArrayList<Apt> appts = new ArrayList<>();

        //Scanner for input
        scnr = new Scanner(System.in);

        //Hashmap to call data
        appointments = new HashMap<>();

        homeScreen HomeScreen = new homeScreen();
        AddScreen addScreen;
        RemoveScreen RemoveScreen;

        updateScreen updateScreen;

        //Temporary Menu for selecting commands
        System.out.println();
        System.out.println("Main Menu");
        System.out.println("1 (Create Appointment))");
        System.out.println("2 (Remove Appointment)");
        System.out.println("3 (Display Appointments)");
        System.out.println("4 (Update Value in Appointments)");
        System.out.println("5 (set return job to true)");
        System.out.println("6 (Import data from file)");
        System.out.println("7 (Exit Application)");

        //Welcome text
        System.out.println("Welcome to the autoTechDMS appointment system\n");

        //Loop to allow multiple commands
        while (done == false) {
            command = homeScreen.retCommand();
            System.out.println(command);
            //ADD command, adds specified user
            if (command.equals("1")) {
                    command = "0";
                continue;
            } else if (command.equals("4")) {






            }
            if (command.equals("5")) {

            }
            if (command.equals("6")) {

            }
            if (command.equals("0")){
                continue;
            }
            else if (command.equals("7")) {
                //Exit program and show thank you message
                System.out.println("Thank you for using the Library Management System");
                break;
            }
        }
    }


    public static String addID() {
        //Initialize and Declare variables
        String ID = "";
        int i = 0;
        /*
        //Scanner object
        Scanner scnr = new Scanner(System.in);

        //Vars for loop
        boolean mvOn = false;
        int idRep = 0;
        double ovRep = 0;
        i++;

        while (mvOn = true) {
            //Input for id (limit to 6 digits)
            //Loop to try new id
            System.out.println("Type new 6 digit ID");
            try {
                while (mvOn = true) {
                    ID = scnr.nextLine();
                    if (ID.matches("[0-9]{6}")) {
                        break;
                    } else {
                        System.out.println("Please Input up to a 6 digit value");
                    }
                }
                idRep = Integer.parseInt(ID);
            } catch (NumberFormatException e) {
                throw new RuntimeException(e);
            }
            break;
        }
        */
        return ID;

    }


    public static String addCar(String car) {

        //Car model
        System.out.println("Type car model");

        return car;
    }

    public static String addOwner() {
        //Initialize and Declare variables
        String owner;

        //Scanner object
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type customer name");
        owner = scnr.nextLine();
        return owner;
    }

    public static String addDate() {
        //Initialize and Declare variables

        //Scanner object
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type appointment date");
        return scnr.nextLine();

    }

    public static String addRType() {
        //Initialize and Declare variables
        String rType;



        //Car model
        System.out.println("Repair type?");
        rType = scnr.nextLine();
        return rType;
    }

    public static Boolean addRTurn() {

        //Return job
        System.out.println("Is this a return job (y/n?)");

        if (scnr.nextLine().matches("y")) {
            return true;
        }
        return false;
    }

    public static String addNote() {
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type note for mechanic/service advisor");
        return scnr.nextLine();
    }

    public static ArrayList<Apt> loadFile(String filename) throws FileNotFoundException, IOException {
        //List to load to
        ArrayList<Apt> ret = new ArrayList<>();

        //Set up reading from file
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        String in = "";

        //Process file
        while ((in = br.readLine()) != null) {
            String[] fields = in.split(","); // aptID, car, owner, date, repair, rturn, note
            ret.add(new Apt(fields[0], fields[1], fields[2], fields[3],fields[4],Boolean.parseBoolean(fields[5]),fields[6]));
        }

        //Close input reading
        br.close();

        return ret;
    }

}
