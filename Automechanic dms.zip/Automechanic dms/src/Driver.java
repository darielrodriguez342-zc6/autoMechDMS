import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.IDN;
import java.util.ArrayList;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Driver {
    static Scanner scnr;
    public static void main(String[] args) {

        //Declare and Initialize variables
        String aptID = "";
        String idToDel;
        String idToUpDt;
        String upDtCh;
        String upDtChOld;
        String upDtChNew;
        String car = "";
        String carNew;
        String owner = "";
        String date = "";
        String repair = "";
        String note = "";
        String rTurnStr = "";
        String command;
        boolean rturn;
        boolean upDtChBool;
        boolean done;
        int rturnInt;


        //Ar list to grab data fed in
        ArrayList<Apt> appts = new ArrayList<>();

        //Scanner for input
        scnr = new Scanner(System.in);

        //Hashmap to call data
        HashMap<String, Apt> appointments = new HashMap<>();

        System.out.println("Input text file location.");
        //for me : C:\Users\Dariel\Desktop\dmsin.txt
        //Input location of file within computer
        String fileName = scnr.nextLine();
        try {
            appts = loadFile(fileName);
            for (Apt apt : appts ) {
                appointments.put(apt.getID(),apt);
            }
            System.out.println(appointments);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        //Temporary Menu for selecting commands
        System.out.println();
        System.out.println("Main Menu");
        System.out.println("add (Create Appointment))");
        System.out.println("remove (Remove Appointment)");
        System.out.println("display (Display Appointments)");
        System.out.println("update (Update Value in Appointments)");
        System.out.println("custom (set return job to true)");
        System.out.println("exit (Exit Application)");

        //Welcome text
        System.out.println("Welcome to the autoTechDMS appointment system\n");

        //Loop to allow multiple commands
        while (done = true) {
            System.out.print("Input command:");

            command = scnr.nextLine();

            //ADD command, adds specified user
            if (command.equals("add")) {

                aptID = addID();
                if(appointments.containsKey(aptID)){
                    System.out.println("id already in database");
                    continue;
                }
                owner = addOwner();
                car = addCar();
                repair = addRType();
                date = addDate();
                rturn = addRTurn();
                rTurnStr = String.valueOf(rturn);
                note = addNote();

                //add to hashmap
                appointments.put( aptID ,new Apt(aptID, car, owner, date, repair, rturn, note));
                System.out.println("Successfully added new appointment for : " + owner);
                
                //REMOVE command, removes selected user
            } else if (command.equals("remove")) {
                //Displays list of appointments  for reference
                System.out.println(appointments);
                System.out.println("Input ID to delete");

                aptID = scnr.nextLine();
                if(!appointments.containsKey(aptID)){
                    System.out.println("id does not exist");
                    continue;
                }

                appointments.remove(aptID);

                //Temporary Menu for selecting commands
                System.out.println();
                System.out.println("Main Menu");
                System.out.println("add (Create Appointment))");
                System.out.println("remove (Remove Appointment)");
                System.out.println("display (Display Appointments)");
                System.out.println("update (Update value in Appointments)");
                System.out.println("custom (set return job to true)");
                System.out.println("exit (Exit Application)");
            } else if (command.equals("display")) {
                //Display list of appointments
                System.out.println(appointments );
                //Temporary Menu for selecting commands
                System.out.println();
                System.out.println("Main Menu");
                System.out.println("add (Create Appointment))");
                System.out.println("remove (Remove Appointment)");
                System.out.println("display (Display Appointments)");
                System.out.println("update (Update value in Appointments)");
                System.out.println("custom (set return job to true)");
                System.out.println("exit (Exit Application)");
            } else if (command.equals("update")) {
                //Update value in appointments

                //Which id to update
                System.out.println("please input id to update");
                idToUpDt = scnr.nextLine();
                if(!appointments.containsKey(idToUpDt)){
                    System.out.println("id does not exist");
                    continue;
                }

                //Which value to update menu
                System.out.println("Value to update?\n");
                System.out.println("Car?");
                System.out.println("Owner?");
                System.out.println("Date?");
                System.out.println("Repair?");
                System.out.println("Return?");
                System.out.println("Note?\n");
                System.out.print("Input response:");
                upDtCh = scnr.nextLine();



                if (upDtCh.equals("car")){

                    //Update value for car
                    System.out.println("new value for car");
                    carNew = scnr.nextLine();

                    appointments.get(idToUpDt).car = carNew ;

                } else if (upDtCh.equals("owner")) {

                    //Update value for owner
                    System.out.println("new value for owner");
                    owner = scnr.nextLine();

                    appointments.get(idToUpDt).owner = owner ;
                } else if (upDtCh.equals("date")) {

                    //Update value for date
                    System.out.println("new value for date");
                    date = scnr.nextLine();

                    appointments.get(idToUpDt).date = date ;
                } else if (upDtCh.equals("repair")) {


                                        
                    System.out.println("new value for repair");
                    repair = scnr.nextLine();

                    appointments.get(idToUpDt).repair = repair ;
                } else if (upDtCh.equals("return")) {

                    //Update value for return with handling for boolean
                    System.out.println("new value for return (case sensitive, true or false)");
                    rTurnStr = scnr.nextLine();

                    appointments.get(idToUpDt).rturn = rTurnStr.equals("true");
                } else if (upDtCh.equals("note")) {

                    //Update value for
                    System.out.println("new value for note");
                    note = scnr.nextLine();

                    appointments.get(idToUpDt).note = note ;
                }else {

                    //no value found and go to next iteration
                    System.out.println("No value found. Returning to menu");
                    continue;
                }


                System.out.println(appointments );
                //Temporary Menu for selecting commands
                System.out.println();
                System.out.println("Main Menu");
                System.out.println("add (Create Appointment))");
                System.out.println("remove (Remove Appointment)");
                System.out.println("display (Display Appointments)");
                System.out.println("update (Update value in Appointments)");
                System.out.println("exit (Exit Application)");
                System.out.println("custom (set return job to true)");
            }
            if (command.equals("custom")) {
                //Quick change return
                System.out.println("input id to quick change");
                idToUpDt = scnr.nextLine();
                appointments.get(idToUpDt).rturn = true;
            }
            else if (command.equals("exit")) {
                //Exit program and show thank you message
                System.out.println("Thank you for using the Library Management System");
                break;
            }
        }
    }


    public static String addID() {
        //Initialize and Declare variables
        String ID = "";
        int i = 0;

        //Scanner object
        Scanner scnr = new Scanner(System.in);

        //Vars for loop
        boolean mvOn = false;
        int idRep = 0;
        double ovRep = 0;
        i++;

        while (mvOn = true) {
            //Input for id (limit to 6 digits)
            //Loop to try new id
            System.out.println("Type new 6 digit ID");
            try {
                while (mvOn = true) {
                    ID = scnr.nextLine();
                    if (ID.matches("[0-9]{6}")) {
                        break;
                    } else {
                        System.out.println("Please Input up to a 6 digit value");
                    }
                }
                idRep = Integer.parseInt(ID);
            } catch (NumberFormatException e) {
                throw new RuntimeException(e);
            }
            break;
        }
        return ID;
    }


    public static String addCar() {
        //Scanner object
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type car model");

        return scnr.nextLine();
    }

    public static String addOwner() {
        //Initialize and Declare variables
        String owner;

        //Scanner object
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type customer name");
        owner = scnr.nextLine();
        return owner;
    }

    public static String addDate() {
        //Initialize and Declare variables

        //Scanner object
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type appointment date");
        return scnr.nextLine();

    }

    public static String addRType() {
        //Initialize and Declare variables
        String rType;



        //Car model
        System.out.println("Repair type?");
        rType = scnr.nextLine();
        return rType;
    }

    public static Boolean addRTurn() {

        //Return job
        System.out.println("Is this a return job (y/n?)");

        if (scnr.nextLine().matches("y")) {
            return true;
        }
        return false;
    }

    public static String addNote() {
        scnr = new Scanner(System.in);

        //Car model
        System.out.println("Type note for mechanic/service advisor");
        return scnr.nextLine();
    }

    public static ArrayList<Apt> loadFile(String filename) throws FileNotFoundException, IOException {
        //List to load to
        ArrayList<Apt> ret = new ArrayList<>();

        //Set up reading from file
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        String in = "";

        //Process file
        while ((in = br.readLine()) != null) {
            String[] fields = in.split(","); // aptID, car, owner, date, repair, rturn, note
            ret.add(new Apt(fields[0], fields[1], fields[2], fields[3],fields[4],Boolean.parseBoolean(fields[5]),fields[6]));
        }

        //Close input reading
        br.close();

        return ret;
    }
    
}
