import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

/**
 * <Strong> DO NOT USE</Strong>
 * Test javaFile, This made sure that the logic was correct in the initial versions of this application,
 * however it is now deprecated
 *
 */
class DriverTest {
    static Scanner scnr;

    @BeforeEach
    void setUp() {
        /*Supplied data for pre-test
        /file location varies. Please find the location for your data file by
        /locating your data file, right-clicking the file, pressing permissions
        /and inputting the location under the general tab, followed by a dash
        /and the text file name .txt */

        String filename = "C:\\Users\\Dariel\\Desktop\\dmsin.txt";
    }


    @Test
    void main() throws IOException {
        //Ar list to grab data fed in
        ArrayList<Apt> appts = new ArrayList<>();
        //Hashmap for testing
        HashMap<String, Apt> appointments = new HashMap<>();

        //Constructing obj
        String command = "add";
        String aptID = "000001";
        String owner = "Dave";
        String repair = "oil change";
        String car = "Bmw";
        String date = "102225";
        Boolean rturn = true;
        String note = "use 5w30";

        //add test
        System.out.println("Add test");
        appointments.put( aptID ,new Apt(aptID, car, owner, date, repair, rturn, note));
        assertEquals(appointments.get(aptID).ID,aptID,"These two aren't equal");
        System.out.println(appointments);
        System.out.println("Add test successful");


        //remove test
        System.out.println("Remove test");
        appointments.remove(aptID);
        System.out.println(appointments + " This should look like {}");

        //update test
        System.out.println("Update test");
        appointments.put( aptID ,new Apt(aptID, car, owner, date, repair, rturn, note));
        System.out.println("(pre updated) value with bmw" + appointments);
        String carNew = "Audi";
        appointments.get("000001").car = carNew ;
        assertEquals(appointments.get(aptID).car,carNew,"These two aren't equal");
        System.out.println("(updated) value with audi " + appointments);
        appointments.remove(aptID);// clear the added value out

        //Read in test
        //List to load to
        ArrayList<Apt> ret = new ArrayList<>();

        //Set up reading from file
        String filename = "C:\\Users\\Dariel\\Desktop\\dmsin.txt";
        FileReader fr = null;
        try {
            fr = new FileReader(filename);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        BufferedReader br = new BufferedReader(fr);
        String in = "";

        //Process file
        while ((in = br.readLine()) != null) {
            String[] fields = in.split(","); // aptID, car, owner, date, repair, rturn, note
            ret.add(new Apt(fields[0], fields[1], fields[2], fields[3],fields[4],Boolean.parseBoolean(fields[5]),fields[6]));
        }

        try {
            appts = ret;
            for (Apt apt : appts ) {
                appointments.put(apt.getID(),apt);
            }
            System.out.println(appointments);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        //Close input reading
        br.close();
        assertEquals(appointments.get("001001").ID,"001001","These two aren't equal");


    }

}