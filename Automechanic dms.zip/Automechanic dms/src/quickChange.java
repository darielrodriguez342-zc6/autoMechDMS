import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class quickChange extends JFrame {
    private JPanel quickChange;
    private JTextField textField1;
    private JButton button1;
    private JButton doneButton;

    quickChange() {
        setContentPane(quickChange);
        this.setTitle("Update Appointment");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean rturn = true;
                Driver.appointments.get(textField1.getText()).rturn = rturn;
            }
        });
        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });
    }
}
