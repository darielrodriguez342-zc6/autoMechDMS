import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RemoveScreen extends JFrame {
    JFrame remScreen = new JFrame();
    private JPanel RemoveScreen;
    private JTextField textField1;
    private JButton deleteButton;
    private JButton closeScreenButton;

    /**
     * The remove class is also simple, The user inputs a primary key to delete.
     * If the key is not found within the Global Hashmap, the user will be met by a message stating that the key does
     * not exist. If the Key does exist, the appointment object will be removed from the list and a query will be sent
     * to remove the row from the database.
     */
    RemoveScreen(){
        setContentPane(RemoveScreen);
        this.setTitle("Remove Appointment");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);



        deleteButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                  if (Driver.appointments.containsKey(textField1.getText()) || !(textField1.getText().isEmpty())) {
                      Driver.appointments.remove(textField1.getText());
                      JOptionPane.showMessageDialog(null, "Appointment removed from record");
                      /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDREMOVE = "DELETE FROM amdmsTblOne WHERE ID= " + (convert to int)textField1.getText() ;
                    stmt.executeQuery(sqlUDREMOVE);
                    Close connection to database
                */

                  } else {
                     System.out.println("id does not exist, or id field is empty");
                  }
             }
        });

        closeScreenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });
    }
}
