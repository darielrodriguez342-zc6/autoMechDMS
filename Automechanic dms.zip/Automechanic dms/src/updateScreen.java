import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class updateScreen extends JFrame {
    private JPanel updateScreen;
    private JButton updateReturnButton;
    private JButton updateNoteButton;
    private JButton updateCarButton;
    private JButton updateOwnerButton;
    private JButton updateRepairButton;
    private JButton updateDateButton;
    private JTextField IDtxtboxTextField;
    private JButton enterIDButton;
    private JTextField enterNewOwnerTextField;
    private JTextField enterNewCarTextField;
    private JTextField enterNewDateTextField;
    private JTextField enterNewRepairTextField;
    private JTextField enterNewReturnTextField;
    private JTextField enterNewNoteTextField;
    private JButton doneButton;
    String IDtoUPDT;
    updateScreen(){
    setContentPane(updateScreen);
    this.setTitle("Update Appointment");
    this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    this.setSize(600, 500);
    this.setLocationRelativeTo(null);
    this.setVisible(true);

        enterIDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Driver.appointments.containsKey(IDtxtboxTextField.getText())&& IDtxtboxTextField.getText().matches("[0-9]{6}")) {
                     IDtoUPDT = IDtxtboxTextField.getText();
                     updateCarButton.setEnabled(true);
                     updateOwnerButton.setEnabled(true);
                     updateDateButton.setEnabled(true);
                     updateRepairButton.setEnabled(true);
                     updateReturnButton.setEnabled(true);
                     updateNoteButton.setEnabled(true);
                setEnabled(false);
                }else {JOptionPane.showMessageDialog(null, "ID slot is empty, or does not exist");}

            }
        });

        updateCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(enterNewCarTextField.getText().isEmpty())){Driver.appointments.get(IDtoUPDT).car = enterNewCarTextField.getText();
                /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDCAR = "UPDATE amdmsTblOne SET car = " + enterNewCarTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDCAR);
                    Close connection to database
                */
                }
                else {JOptionPane.showMessageDialog(null, "Car slot is empty");}
            }
        });

        updateOwnerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(enterNewOwnerTextField.getText().isEmpty())){Driver.appointments.get(IDtoUPDT).owner = enterNewOwnerTextField.getText();
                /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDOWNER = "UPDATE amdmsTblOne SET owner = " + enterNewOwnerTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDOWNER);
                    Close connection to database
                */
                }
                else {JOptionPane.showMessageDialog(null, "Owner slot is empty");}

            }
        });

        updateDateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(!(enterNewDateTextField.getText().isEmpty())){Driver.appointments.get(IDtoUPDT).date = enterNewDateTextField.getText();
                 /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDDATE = "UPDATE amdmsTblOne SET date = " + enterNewDateTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDDATE);
                    Close connection to database
                */
                }
                else {JOptionPane.showMessageDialog(null, "Owner slot is empty");}

            }
        });

        updateRepairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(enterNewRepairTextField.getText().isEmpty())){Driver.appointments.get(IDtoUPDT).repair = enterNewRepairTextField.getText();
                 /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDREPAIR = "UPDATE amdmsTblOne SET repair = " + enterNewRepairTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDREPAIR);
                    Close connection to database
                */
                }
                else {JOptionPane.showMessageDialog(null, "Repair slot is empty");}
            }
        });

        updateReturnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean rturn = Boolean.valueOf(enterNewReturnTextField.getText());
                Driver.appointments.get(IDtoUPDT).rturn = rturn;

                if(!(enterNewReturnTextField.getText().isEmpty())&&(enterNewReturnTextField.equals("true")||enterNewReturnTextField.equals("false"))){rturn = Boolean.valueOf(enterNewReturnTextField.getText());
                    Driver.appointments.get(IDtoUPDT).rturn = rturn;
                /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDREPAIR = "UPDATE amdmsTblOne SET repair = " + enterNewReturnTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDREPAIR);
                    Close connection to database
                */
                }
                else{JOptionPane.showMessageDialog(null, "Return slot is empty, or not in correct syntax");}

            }
        });

        updateNoteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Driver.appointments.get(IDtoUPDT).note = enterNewNoteTextField.getText();
                if(!(enterNewNoteTextField.getText().isEmpty())){Driver.appointments.get(IDtoUPDT).note = enterNewNoteTextField.getText();
                /*
                    open connection
                    String url = "jdbc:sqlite:C:\\Program Files\\SQLiteStudio\\automechdb.db";
                    Connection con = null;
                    con = DriverManager.getConnection(url);
                    Statement stmt = con.CreateStatement();
                    String sqlUDNOTE = "UPDATE amdmsTblOne SET note = " + enterNewNoteTextField.getText() + " FROM amdmsTblOne WHERE id = " + (convert to int)IDtoUPDT;
                    stmt.executeQuery(sqlUDNOTE);
                    Close connection to database
                */}
                else {JOptionPane.showMessageDialog(null, "Note slot is empty");}
            }
        });

        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new homeScreen();
            }
        });
}
}
