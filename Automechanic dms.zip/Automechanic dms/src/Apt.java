public class Apt {
    String ID;
    String car;
    String owner;
    String date;
    String repair;
    boolean rturn;
    String note;

    public Apt(String ID, String car, String owner, String date, String repair, boolean rturn, String note) {
        this.ID = ID;
        this.car = car;
        this.owner = owner;
        this.date = date;
        this.repair = repair;
        this.rturn = rturn;
        this.note = note;
    }

    public String getID() {
        return ID;
    }

    public void setAptID(String aptID) {
        this.ID = aptID;
    }

    public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRepair() {
        return repair;
    }

    public void setRepair(String repair) {
        this.repair = repair;
    }

    public boolean isRturn() {
        return rturn;
    }

    public void setRturn(boolean rturn) {
        this.rturn = rturn;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Apt{" +
                "aptID='" + ID + '\'' +
                ", car='" + car + '\'' +
                ", owner='" + owner + '\'' +
                ", date='" + date + '\'' +
                ", repair='" + repair + '\'' +
                ", rturn=" + rturn +
                ", note='" + note + '\'' +
                '}';
    }
}
